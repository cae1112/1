@echo off
REM Пример батника
echo Build demo stub
